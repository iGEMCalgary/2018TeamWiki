from bs4 import BeautifulSoup
import requests

# Scraping 2008-2014 Wiki Links
source = requests.get('http://igem.org/Team_Wikis?year=2014').text
soup = BeautifulSoup(source, 'lxml')
content = soup.find('div', id='content_Page')
links = []
linksWithSoftware = []
for wiki in content.findAll('a'):
    links.append(wiki['href'] + "/Software")

for i in range(0, len(links), 1):
    wikiSource = requests.get(links[i]).text
    # if "There is currently no text in this page." in wikiSource:
    #     print("No software here: " + links[i])
    # else:
    #     print("Software here: " + links[i])
    #     linksWithSoftware.append(links[i])
    if "There is currently no text in this page." not in wikiSource:
        linksWithSoftware.append(links[i])

print("\nWikis with Software:")
for i in range(0, len(linksWithSoftware), 1):
    print(linksWithSoftware[i])

for i in range(0, len(linksWithSoftware), 1):
# i = 0
    print("\nParagraphs from " + linksWithSoftware[i] + ":")
    softwareWikiSource = requests.get(linksWithSoftware[i]).text
    soup = BeautifulSoup(softwareWikiSource, 'lxml')
    content = soup.find('div', id='bodyContent')
    paragraphs = []
    j = 1
    for para in content.findAll('p'):
        print("\nParagraph " + str(j) + ": " + "".join(line.strip() for line in para.text.split("\n")))
        j += 1
        # paragraphs.append(para.text)
    # print("Paragraph " + 0 + 1 + ": " + "".join(line.strip() for line in paragraphs[0].split("\n")))

# Scraping 2015- Wiki Links
# source = requests.get('http://igem.org/Team_Wikis?year=2015').text
# soup = BeautifulSoup(source, 'lxml')
# content = soup.find('div', id='content_Page')
# links = []
# linksWithSoftware = []
# for wiki in content.findAll('a'):
#     links.append(wiki['href'] + "/Software")
# 
# for i in range(0, len(links), 1):
#     wikiSource = requests.get(links[i]).text
#     # if "There is currently no text in this page." in wikiSource:
#     #     print("No software here: " + links[i])
#     # else:
#     #     print("Software here: " + links[i])
#     #     linksWithSoftware.append(links[i])
#     if "There is currently no text in this page." not in wikiSource:
#         linksWithSoftware.append(links[i])
# 
# print("\nWikis with Software:")
# for i in range(0, len(linksWithSoftware), 1):
#     print(linksWithSoftware[i])
# 
# for i in range(0, len(linksWithSoftware), 1):
# # i = 0
#     print("\nParagraphs from " + linksWithSoftware[i] + ":")
#     softwareWikiSource = requests.get(linksWithSoftware[i]).text
#     soup = BeautifulSoup(softwareWikiSource, 'lxml')
#     content = soup.find('div', id='bodyContent')
#     paragraphs = []
#     j = 1
#     for para in content.findAll('p'):
#         print("\nParagraph " + str(j) + ": " + "".join(line.strip() for line in para.text.split("\n")))
#         j += 1
#         # paragraphs.append(para.text)
#     # print("Paragraph " + 0 + 1 + ": " + "".join(line.strip() for line in paragraphs[0].split("\n")))