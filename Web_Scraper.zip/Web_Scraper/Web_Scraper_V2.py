from bs4 import BeautifulSoup
import requests
import webbrowser
import time

userChoice = input('Enter year: ')

start_time = time.time()

# Scraping Wiki Links
counter = 0
source = requests.get('http://igem.org/Team_Wikis?year=' + userChoice).text
soup = BeautifulSoup(source, 'lxml')
content = soup.find('div', id='content_Page')
links = []
linksWithSoftware = []
for wiki in content.findAll('a'):
    links.append(wiki['href'] + "/Software")

for i in range(0, len(links), 1):
    wikiSource = requests.get(links[i]).text
    # wikiSoup = BeautifulSoup(wikiSource, 'lxml')
    # wikiContent = wikiSoup.find('div', id='mw-content-text')
    # len(wikiContent.text) == 3:
    if "There is currently no text in this page." in wikiSource or\
        "In order to be considered for the" in wikiSource or\
        "you must fill this page." in wikiSource or\
        "This page is used by the judges to evaluate your team for the" in wikiSource or\
        "Regardless of the topic, iGEM projects often create or adapt computational tools to move the project forward." in wikiSource:
        pass
    else:
        linksWithSoftware.append(links[i])

print("\nWikis with Software:")
for i in range(0, len(linksWithSoftware), 1):
    print(linksWithSoftware[i])

for i in range(0, len(linksWithSoftware), 1):
    print("\nParagraphs from " + linksWithSoftware[i] + ":")
    softwareWikiSource = requests.get(linksWithSoftware[i]).text
    soup = BeautifulSoup(softwareWikiSource, 'lxml')
    content = soup.find('div', id='bodyContent')
    paragraphs = []
    for para in content.findAll('p'):
        temp = "".join(line.strip() for line in para.text.split("\n"))
        if "<style" in str(para) or "</style>" in str(para) or\
                "<script" in str(para) or "</script>" in str(para) or\
                len(temp) == 0:
            pass
        else:
            paragraphs.append("".join(line.strip() for line in para.text.split("\n")))
    finalDescription = ""
    j = 0
    while len(finalDescription) < 500 and j < len(paragraphs):
        k = 0
        while len(finalDescription) < 500 and k < len(paragraphs[j]):
            finalDescription += paragraphs[j][k]
            k += 1
        j += 1
        finalDescription += " "
    # if len(finalDescription) > 0:
    #     if finalDescription[len(finalDescription) - 1] == " ":
    #         finalDescription = finalDescription[:-1]
    finalDescription += "..."
    # webbrowser.open(linksWithSoftware[i])
    print(finalDescription)
    counter += 1

print("\nTime elapsed: {:.2f}s".format(time.time() - start_time))
print("\nSoftwares found: " + str(counter))

# # Scraping 2015 Wiki Links
# source = requests.get('http://igem.org/Team_Wikis?year=2015').text
# soup = BeautifulSoup(source, 'lxml')
# content = soup.find('div', id='content_Page')
# links = []
# linksWithSoftware = []
# for wiki in content.findAll('a'):
#     links.append(wiki['href'] + "/Software")
#
# for i in range(0, len(links), 1):
#     wikiSource = requests.get(links[i]).text
#     # if "There is currently no text in this page." in wikiSource:
#     #     print("No software here: " + links[i])
#     # else:
#     #     print("Software here: " + links[i])
#     #     linksWithSoftware.append(links[i])
#     if "In order to be considered for the" not in wikiSource and\
#             "you must fill this page." not in wikiSource:
#         linksWithSoftware.append(links[i])
#
# print("\nWikis with Software:")
# for i in range(0, len(linksWithSoftware), 1):
#     print(linksWithSoftware[i])
#
# for i in range(0, len(linksWithSoftware), 1):
# # i = 0
#     print("\nParagraphs from " + linksWithSoftware[i] + ":")
#     softwareWikiSource = requests.get(linksWithSoftware[i]).text
#     soup = BeautifulSoup(softwareWikiSource, 'lxml')
#     content = soup.find('div', id='bodyContent')
#     paragraphs = []
#     j = 1
#     for para in content.findAll('p'):
#         print("\nParagraph " + str(j) + ": " + "".join(line.strip() for line in para.text.split("\n")))
#         j += 1
#         # paragraphs.append(para.text)
#     # print("Paragraph " + 0 + 1 + ": " + "".join(line.strip() for line in paragraphs[0].split("\n")))

# start_time = time.time()
#
# # Scraping 2016- Wiki Links
# source = requests.get('http://igem.org/Team_Wikis?year=2016').text
# soup = BeautifulSoup(source, 'lxml')
# content = soup.find('div', id='content_Page')
# links = []
# linksWithSoftware = []
# for wiki in content.findAll('a'):
#     links.append(wiki['href'] + "/Software")
#
# for i in range(0, len(links), 1):
#     wikiSource = requests.get(links[i]).text
#     # if "There is currently no text in this page." in wikiSource:
#     #     print("No software here: " + links[i])
#     # else:
#     #     print("Software here: " + links[i])
#     #     linksWithSoftware.append(links[i])
#     wikiSoup = BeautifulSoup(wikiSource, 'lxml')
#     wikiContent = wikiSoup.find('div', id='mw-content-text')
#
#
#     if "There is currently no text in this page." in wikiSource or\
#             "This page is used by the judges to evaluate your team for the" in wikiSource or\
#             "Regardless of the topic, iGEM projects often create or adapt computational tools to move the project forward." in wikiSource or\
#             len(wikiContent.text) == 3:
#         pass
#     else:
#         linksWithSoftware.append(links[i])
#
# print("\nWikis with Software:")
# for i in range(0, len(linksWithSoftware), 1):
#     print(linksWithSoftware[i])
#     webbrowser.open(linksWithSoftware[i])
#
# print("time elapsed: {:.2f}s".format(time.time() - start_time))

# for i in range(0, len(linksWithSoftware), 1):
# # i = 0
#     print("\nParagraphs from " + linksWithSoftware[i] + ":")
#     softwareWikiSource = requests.get(linksWithSoftware[i]).text
#     soup = BeautifulSoup(softwareWikiSource, 'lxml')
#     content = soup.find('div', id='bodyContent')
#     paragraphs = []
#     j = 1
#     for para in content.findAll('p'):
#         print("\nParagraph " + str(j) + ": " + "".join(line.strip() for line in para.text.split("\n")))
#         j += 1
        # paragraphs.append(para.text)
    # print("Paragraph " + 0 + 1 + ": " + "".join(line.strip() for line in paragraphs[0].split("\n")))