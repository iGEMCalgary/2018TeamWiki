from bs4 import BeautifulSoup
import requests

source = requests.get('http://2017.igem.org/Team:Calgary').text

soup = BeautifulSoup(source, 'lxml')

title = soup.find('title')

print("\nTitle:\n\n\t" + title.text)

body = soup.find('body')

div = body.div

div_1 = div.find('div', id='content')

div_2 = div_1.find('div', id='HQ_page')

div_3 = div_2.find('div', id='bodyContent')

div_4 = div_3.find('div', id='mw-content-text')

div_5 = div_4.find('div', id='MainContent')

print("\nDescription:\n\n\t" + div_5.p.text)
