import time

import requests
from bs4 import BeautifulSoup

# Gets Links
def getLinks(teamWikisPageContent):
    links = []
    for link in teamWikisPageContent.findAll('a'):
        links.append(link['href'] + "/Software")
    return links

# Gets Links with Content
def getLinksWithContent(links):
    linksWithContent = []
    for i in range(0, len(links), 1):
        wikiSource = requests.get(links[i]).text
        if "There is currently no text in this page." in wikiSource or "In order to be considered for the" in \
                wikiSource or "you must fill this page." in wikiSource or "This page is used by the judges to " \
                "evaluate your team for the" in wikiSource or "Regardless of the topic, iGEM projects often create " \
                "or adapt computational tools to move the project forward." in wikiSource:
            pass
        else:
            linksWithContent.append(links[i])
    return linksWithContent

# Prints Links with Content
def printLinksWithContent(linksWithContent):
    print("\nLinks with Content:")
    for i in range(0, len(linksWithContent), 1):
        print(linksWithContent[i])

# Prints Link Descriptions
def printLinkDescriptions(linksWithContent):
    counter = 0
    for i in range(0, len(linksWithContent), 1):
        print("\nLink Description from " + linksWithContent[i] + ":")
        wikiWithContentSource = requests.get(linksWithContent[i]).text
        wikiWithContentSoup = BeautifulSoup(wikiWithContentSource, 'lxml')
        wikiWithContentContent = wikiWithContentSoup.find('div', id='bodyContent')
        paragraphs = []
        for paragraph in wikiWithContentContent.findAll('p'):
            temp = "".join(line.strip() for line in paragraph.text.split("\n"))
            if "<style" in str(paragraph) or "</style>" in str(paragraph) or "<script" in str(paragraph) or \
                    "</script>" in str(paragraph) or len(temp) == 0:
                pass
            else:
                paragraphs.append("".join(line.strip() for line in paragraph.text.split("\n")))
        description = ""
        i = 0
        while len(description) < 500 and i < len(paragraphs):
            j = 0
            while len(description) < 500 and j < len(paragraphs[j]):
                description += paragraphs[i][j]
                j += 1
            i += 1
            description += " "
        description += "..."
        print(description)
        counter += 1
    return counter

# Main Method
def main():
    year = input("Enter year: ")
    startTime = time.time()
    # Get Scraping Components of Team Wikis Page
    teamWikisPageSource = requests.get('http://igem.org/Team_Wikis?year=' + year).text
    teamWikisPageSoup = BeautifulSoup(teamWikisPageSource, 'lxml')
    teamWikisPageContent = teamWikisPageSoup.find('div', id='content_Page')
    # Get Links
    links = getLinks(teamWikisPageContent)
    # Get Links with Content
    linksWithContent = getLinksWithContent(links)
    # Print Links with Content
    printLinksWithContent(linksWithContent)
    # Print Link Descriptions
    numberOfLinksWithContent = printLinkDescriptions(linksWithContent)
    print("\nTime elapsed: {:.2f} s".format(time.time() - startTime))
    print("\nNumber of links with content found: " + str(numberOfLinksWithContent))

# Call to Main Method
main()